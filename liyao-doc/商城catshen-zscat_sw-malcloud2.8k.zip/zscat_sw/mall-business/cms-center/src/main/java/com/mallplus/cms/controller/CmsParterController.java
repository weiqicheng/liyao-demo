package com.mallplus.cms.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author zscat
 * @since 2019-04-28
 */
@Controller
@RequestMapping("/cms/cmsParter")
public class CmsParterController {

}

