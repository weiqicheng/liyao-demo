package com.mallplus.cms.service;

import com.mallplus.cms.entity.CmsPrefrenceArea;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 优选专区 服务类
 * </p>
 *
 * @author zscat
 * @since 2019-04-17
 */
public interface ICmsPrefrenceAreaService extends IService<CmsPrefrenceArea> {

}
