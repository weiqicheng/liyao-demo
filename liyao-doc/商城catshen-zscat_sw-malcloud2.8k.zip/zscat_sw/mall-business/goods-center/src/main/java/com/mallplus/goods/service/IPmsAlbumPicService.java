package com.mallplus.goods.service;

import com.mallplus.goods.entity.PmsAlbumPic;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 画册图片表 服务类
 * </p>
 *
 * @author zscat
 * @since 2019-04-19
 */
public interface IPmsAlbumPicService extends IService<PmsAlbumPic> {

}
