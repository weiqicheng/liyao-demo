package com.mallplus.member.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.mallplus.member.entity.SysArea;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author zscat
 * @since 2019-04-14
 */
public interface ISysAreaService extends IService<SysArea> {

}
